package assistedprojectjava;
import java.util.Scanner;
public class SumInRange {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int n = input.nextInt();

        int[] array = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            array[i] = input.nextInt();
        }

        System.out.print("Enter the left index (L): ");
        int L = input.nextInt();

        System.out.print("Enter the right index (R): ");
        int R = input.nextInt();

        int sum = calculateSumInRange(array, L, R);
        System.out.println("Sum of elements within the given range: " + sum);

        input.close();
    }

    public static int calculateSumInRange(int[] array, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += array[i];
        }
        return sum;
    }
}

