package assistedprojectjava;
import java.util.Stack;

public class StackElements {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        
        stack.push(22);
        stack.push(33);
        stack.push(44);
        
        System.out.println("Stack: " + stack);
        
       
        int removedElement = stack.pop();
        System.out.println("Removed element: " + removedElement);
        
        System.out.println("Stack after Removed: " + stack);
        
        
        int topElement = stack.peek();
        System.out.println("Top element: " + topElement);
    }
}

