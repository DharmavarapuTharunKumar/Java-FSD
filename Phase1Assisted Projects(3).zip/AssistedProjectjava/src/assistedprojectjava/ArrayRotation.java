package assistedprojectjava;
public class ArrayRotation {
	public static void main(String[] args) {
        int[] array = {91,92,93,94,95,96,97,98,99,100};
        int rotationSteps = 5;
        rotateArray(array, rotationSteps);
        System.out.println("Rotated Array:");
        printArray(array);
    }
    
    // Function to right rotate an array by 'steps'
    public static void rotateArray(int[] arr, int steps) {
        int length = arr.length;
        
        // Create a temporary array of size steps
        int[] temp = new int[steps];
        
        // Copy the last 'steps' elements to temp array
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[length - steps + i];
        }
        
        // Shift the remaining elements to the right
        for (int i = length - steps - 1; i >= 0; i--) {
            arr[i + steps] = arr[i];
        }
        
        // Copy the elements from temp array to the beginning of the original array
        for (int i = 0; i < steps; i++) {
            arr[i] = temp[i];
        }
    }
    
    // Function to print an array
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
