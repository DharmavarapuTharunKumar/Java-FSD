package assistedprojectjava;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;

	public class FourthSmallestElement {
	    public static int findFourthSmallest(List<Integer> numbers) {
	        if (numbers.size() < 4) {
	            throw new IllegalArgumentException("List should contain at least 4 elements");
	        }
	        
	        Collections.sort(numbers);
	        return numbers.get(3);
	    }

	    public static void main(String[] args) {
	        List<Integer> numbers = new ArrayList<>();
	        numbers.add(7);
	        numbers.add(22);
	        numbers.add(36);
	        numbers.add(45);
	        numbers.add(39);
	        numbers.add(10);
	        numbers.add(89);
	        numbers.add(65);
	        numbers.add(40);

	        int fourthSmallest = findFourthSmallest(numbers);
	        System.out.println("The fourth smallest element is: " + fourthSmallest);
	    }
	}


