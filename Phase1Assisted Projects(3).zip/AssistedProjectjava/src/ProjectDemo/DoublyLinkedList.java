package ProjectDemo;
class Node {
    int data;
    Node prev;
    Node next;

    public Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

public class DoublyLinkedList {
    private Node head;
    private Node tail;

    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void traverseForward() {
        if (head == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Node curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
        System.out.println();
    }

    public void traverseBackward() {
        if (tail == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Node curr = tail;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.insert(22);
        list.insert(24);
        list.insert(26);
        list.insert(28);
        list.insert(30);

        System.out.println("Traversing the Doubly Linked List in forward direction:");
        list.traverseForward();

        System.out.println("Traversing the Doubly Linked List in backward direction:");
        list.traverseBackward();
    }

}
